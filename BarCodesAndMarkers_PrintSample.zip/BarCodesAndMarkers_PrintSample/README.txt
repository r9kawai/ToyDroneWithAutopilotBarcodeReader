Someone print out "arm_64.pdf" on A4 papaer, Take a size of each AR marker square 51x51mm.
(a size is wrote at "PARAM_2" in "drone_ar_flight.py")
